HOW TO INSTALL
------------------

Use git

```
git init
git add https://github.com/elkhunsu/testing.git
```

update composer in cmd

```
composer update
```

see the signup menu for details