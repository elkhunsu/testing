<?php

use yii\db\Migration;

class m171101_035032_yii2_advanced extends Migration
{
    public function safeUp()
    {

    }

    public function safeDown()
    {
        echo "m171101_035032_yii2_advanced cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m171101_035032_yii2_advanced cannot be reverted.\n";

        return false;
    }
    */
}
